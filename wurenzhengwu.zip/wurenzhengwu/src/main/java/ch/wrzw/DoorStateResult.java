package ch.wrzw;


public class DoorStateResult {
    int code = -1;
    boolean isDoorOpen = false;

    Result mResult;

    protected DoorStateResult() {

        mResult = new Result("DoorStateResult");
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public boolean isDoorOpen() {
        return isDoorOpen;
    }

    public void setDoorOpen(boolean doorOpen) {
        isDoorOpen = doorOpen;
    }

    public Result getResult() {
        return mResult;
    }

    public void setResult(Result mResult) {
        this.mResult = mResult;
    }
}
