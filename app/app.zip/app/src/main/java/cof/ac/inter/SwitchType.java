package cof.ac.inter;

public enum SwitchType {

	ON,
	OFF;
}
