package cof.ac.inter;

public enum WaterType {

	HOT_WATER,
	COLD_WATER;
}
