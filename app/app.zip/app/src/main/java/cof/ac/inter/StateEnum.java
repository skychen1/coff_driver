package cof.ac.inter;

public enum StateEnum {

	IDLE,
	DOOR_OPNE,
	TESTING,
	CLEANING,
	STERILIZING,
	DOWN_CUP,
	MAKING,
	DOWN_POWDER,
	FINISH,
	WARNING,
	HAS_ERR,
	HEAT_POT,
	INIT,
	UNKNOW_STATE;
	
}
