package cof.ac.inter;

public enum ContainerType {

	BEAN_CONTAINER,
	HOTWATER_CONTAINER,
	NO_ONE,
	NO_TOW,
	NO_THREE,
	NO_FOUR,
	NO_FIVE,
	NO_SIX;
}
