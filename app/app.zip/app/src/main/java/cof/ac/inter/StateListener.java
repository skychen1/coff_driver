package cof.ac.inter;

public interface StateListener {

	public void stateArrived(MachineState state);
}
