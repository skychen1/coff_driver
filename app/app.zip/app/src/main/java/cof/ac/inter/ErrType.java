package cof.ac.inter;

public enum ErrType {

	NO_Err,
	WASTEFULL_ERR,
	CUPSHELF_ERR,
	DOOROPNE_ERR,
	STATECODE_ERR,
	BEAN_ERR,
	WATER_ERR;
}
